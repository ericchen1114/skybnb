package model.bean;

public class SysDiagrams {

}
