package model.bean;

public class WishList {

}
