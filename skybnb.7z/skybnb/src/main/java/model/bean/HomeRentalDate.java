package model.bean;

public class HomeRentalDate {

}
