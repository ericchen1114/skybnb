package controller;

public class BackstageCustomerReportUpdated {

}
